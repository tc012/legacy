Thank you for downloading this, I have archived the files so you can still install on Chrome.

YOU WILL NEED TO SIDELOAD THE EXTENSION AS THE CRX FILES REFUSES TO BE ENABLED BECAUSE CHROME IS CHROME.

Only reason this exists is because Google took it down on the web store because its "not following the best guidelines or what ever"

Kind regards,

Andrew (tc012)